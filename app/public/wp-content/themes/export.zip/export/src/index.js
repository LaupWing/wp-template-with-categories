
if(window.location.pathname === "/"){
   import("./modules/FormSteps")
}
import "./modules/Socials"
import SideNav from "./modules/SideNav"
new SideNav()